m = myFunction(21)
try
    n = squareMe(18)
catch err
    fprintf('Gotcha!\n')
end