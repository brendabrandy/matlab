function viewImage (I, varargin)

