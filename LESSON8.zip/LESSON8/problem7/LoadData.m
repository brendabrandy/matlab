load data
[ax, p, v] = plotyy(time, position, time, velocity);